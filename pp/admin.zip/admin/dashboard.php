<?php
// 1. Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "pp");

// 2. Ambil data dari tabel pesan
$query = "SELECT * FROM pesan ORDER BY id DESC";
$tampil = mysqli_query($koneksi, $query);
?>

<div class="container mt-5">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Daftar Pesan Masuk</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Pesan</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        while($data = mysqli_fetch_array($tampil)): 
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= htmlspecialchars($data['nama']); ?></td>
                            <td><?= htmlspecialchars($data['email']); ?></td>
                            <td><?= nl2br(htmlspecialchars($data['isi_pesan'])); ?></td>
                            <td><?= $data['tanggal']; ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<a href="index.php?page=profile" class="btn btn-outline-primary w-100">
  Kelola Profile
</a>

<a href="index.php?page=skills" class="btn btn-outline-success w-100">
  Kelola Skills
</a>

<a href="index.php?page=projects" class="btn btn-outline-info w-100">
  Kelola Projects
</a>

<a href="index.php?page=education" class="btn btn-outline-warning w-100">
  Education & Experience
</a>

<a href="index.php?page=pesan" class="btn btn-outline-danger w-100">
  Pesan Contact
</a>
