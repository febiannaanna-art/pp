<?php
include '../koneksi.php';

$query = mysqli_query($koneksi, "SELECT * FROM pesan_contact ORDER BY id DESC");
?>

<h4 class="mb-4">📩 Pesan Masuk</h4>

<div class="card">
  <div class="card-body">
    <table class="table table-bordered table-hover">
      <thead class="table-dark">
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>Email</th>
          <th>Pesan</th>
          <th>Tanggal</th>
        </tr>
      </thead>
      <tbody>

        <?php
        $no = 1;
        if(mysqli_num_rows($query) > 0){
          while($row = mysqli_fetch_assoc($query)){
        ?>
          <tr>
            <td><?= $no++; ?></td>
            <td><?= htmlspecialchars($row['nama']); ?></td>
            <td><?= htmlspecialchars($row['email']); ?></td>
            <td><?= htmlspecialchars($row['pesan']); ?></td>
            <td><?= $row['created_at'] ?? '-'; ?></td>
          </tr>
        <?php
          }
        } else {
        ?>
          <tr>
            <td colspan="5" class="text-center">Belum ada pesan masuk</td>
          </tr>
        <?php } ?>

      </tbody>
    </table>
  </div>
</div>
