<?php
session_start();

// PROSES LOGIN (DUMMY)
if (isset($_POST['login'])) {
    // nanti bisa ditambah validasi email & password
    $_SESSION['login'] = true;

    // arahkan ke dashboard admin
    header("Location: ../index.php");
    exit;
}
?>
<!doctype html>
<html
  lang="en"
  class="layout-wide customizer-hide"
  data-assets-path="/pp/template-dashboard/assets/"
  data-template="vertical-menu-template-free">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title>Login | Admin Dashboard</title>

  <!-- Core CSS -->
  <link rel="stylesheet" href="/pp/template-dashboard/assets/vendor/css/core.css" />
  <link rel="stylesheet" href="/pp/template-dashboard/assets/vendor/css/theme-default.css" />
  <link rel="stylesheet" href="/pp/template-dashboard/assets/css/demo.css" />
  <link rel="stylesheet" href="/pp/template-dashboard/assets/vendor/css/pages/page-auth.css" />
</head>

<body>

<div class="container-xxl">
  <div class="authentication-wrapper authentication-basic container-p-y">
    <div class="authentication-inner">
      <div class="card">
        <div class="card-body">

          <h4 class="mb-2">Welcome 👋</h4>
          <p class="mb-4">Please sign in to your account</p>

          <!-- FORM LOGIN -->
          <form method="POST">

            <div class="mb-3">
              <label class="form-label">Email / Username</label>
              <input type="text" class="form-control" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" required>
            </div>

            <button type="submit" name="login" class="btn btn-primary w-100">
              Login
            </button>

          </form>

          <p class="text-center mt-3">
            <span>Belum punya akun?</span>
            <a href="register.php">Register</a>
          </p>

        </div>
      </div>
    </div>
  </div>
</div>

<!-- JS -->
<script src="/pp/template-dashboard/assets/vendor/libs/jquery/jquery.js"></script>
<script src="/pp/template-dashboard/assets/vendor/js/bootstrap.js"></script>
<script src="/pp/template-dashboard/assets/js/main.js"></script>

</body>
</html>
