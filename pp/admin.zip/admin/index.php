<?php
// admin/index.php
$page = $_GET['page'] ?? 'dashboard';
?>

<!doctype html>
<html
  lang="en"
  class="layout-menu-fixed layout-compact"
  data-assets-path="/pp/template-dashboard/assets/"
  data-template="vertical-menu-template-free">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard Admin</title>

  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="/pp/template-dashboard/assets/img/favicon/favicon.ico" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Core CSS -->
  <link rel="stylesheet" href="/pp/template-dashboard/assets/vendor/css/core.css" />
  <link rel="stylesheet" href="/pp/template-dashboard/assets/vendor/css/theme-default.css" />
  <link rel="stylesheet" href="/pp/template-dashboard/assets/css/demo.css" />

  <!-- Helpers -->
  <script src="/pp/template-dashboard/assets/vendor/js/helpers.js"></script>
  <script src="/pp/template-dashboard/assets/js/config.js"></script>
</head>

<body>

<div class="layout-wrapper layout-content-navbar">
  <div class="layout-container">

    <!-- SIDEBAR -->
    <?php include 'partials/sidebar.php'; ?>

    <!-- PAGE -->
    <div class="layout-page">

      <!-- NAVBAR -->
      <?php include 'partials/navbar.php'; ?>

      <!-- CONTENT -->
      <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">

          <?php
          switch ($page) {
            case 'profile':
              include 'profile.php';
              break;

            case 'skills':
              include 'skills.php';
              break;

            case 'projects':
              include 'projects.php';
              break;

            case 'education':
              include 'education.php';
              break;

            case 'pesan':
              include 'pesan_masuk.php';
              break;

            default:
              include 'dashboard.php';
              break;
          }
          ?>

        </div>

        <!-- FOOTER -->
        <?php include 'partials/footer.php'; ?>

        <div class="content-backdrop fade"></div>
      </div>
    </div>
  </div>

  <div class="layout-overlay layout-menu-toggle"></div>
</div>

<!-- CORE JS -->
<script src="/pp/template-dashboard/assets/vendor/libs/jquery/jquery.js"></script>
<script src="/pp/template-dashboard/assets/vendor/libs/popper/popper.js"></script>
<script src="/pp/template-dashboard/assets/vendor/js/bootstrap.js"></script>
<script src="/pp/template-dashboard/assets/vendor/js/menu.js"></script>
<script src="/pp/template-dashboard/assets/js/main.js"></script>

</body>
</html>
